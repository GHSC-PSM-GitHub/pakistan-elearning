<style>
    #imgdesign {
        background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
        border:2px solid #b5e4cb;
            padding: 15px;
  margin: 8px;
    }
    #textdesign 
    {
         text-align: center;
/*        padding: 10px 20px;
        font-size:20px;
    font-weight:bold;*/
    }
.buttons {
  background-color: #309255; /* Green */
  border: none;
  color: white;
  padding: 2px 0px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 0px 0px;
  transition-duration: 0.4s;
  cursor: pointer;
  border-radius: 4px;
  height:25px;
  width: 70px;
}

.button1s {
  background-color: #309255; 
  color: #fff; 
  border: 2px solid #309255;
}

.button1s:hover {
  background-color: #52c47c;
  color: white;
}
</style>
        <!-- Mobile Menu Start -->
        
        <!-- Mobile Menu End -->

        <!-- Overlay Start -->
        <div class="overlay"></div>
        <!-- Overlay End -->

        <!-- Page Banner Start -->
        <div class="section page-banner">

            <img class="shape-1 animation-round" src="<?php echo base_url(); ?>assets/images/shape/shape-8.png" alt="Shape">

            <img class="shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-23.png" alt="Shape">

            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">Course Details</li>
                    </ul>
                    <h2 class="title">Course : <span> LHW Program</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="<?php echo base_url(); ?>assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>

                <img class="icon-shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-6.png" alt="Shape">

            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="<?php echo base_url(); ?>assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="<?php echo base_url(); ?>assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

        <!-- Courses Start -->
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-8">

                        <!-- Courses Details Start -->
                        <div class="courses-details">

                            <div class="courses-details-images" style="height:250px;">
                                <img src="<?php echo base_url(); ?>assets/images/courses/lhw_digital_diary.jpg" alt="Courses Details">
                                <!--<span class="tags">Finance</span>-->

<!--                                <div class="courses-play" >
                                    <img src="<?php echo base_url(); ?>assets/images/courses/circle-shape.png" alt="Play">
                                    <a class="play video-popup" href="https://www.youtube.com/watch?v=Wif4ZkwC0AM"><i class="flaticon-play"></i></a>
                                </div>-->
                            </div>

                            <h2 class="title">LHW Program</h2>

                            <div class="courses-details-admin">
                                <div class="admin-author">
                                    <div class="author-thumb">
                                        <img src="<?php echo base_url(); ?>assets/images/author/lhw.png" alt="Author">
                                    </div>
                                    <div class="author-content">
                                        <a class="name" href="#">GHSC-PSM</a>
                                    </div>
                                </div>
                            </div>

                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab">

                                <!-- Details Tab Menu End -->

                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    <h3 class="tab-title">Introduction:</h3>
                                                    <p>
                                                        The Lady Health Worker Program (LHWP) was established in 1994, with the goal of providing primary care services to underserved populations in rural and urban areas. In 2003, the national strategic plan set two goals: 
                                                        <br>(1) Improving quality of services 
                                                        <br>(2) Expanding coverage of the LHWP through the deployment of 100,000 Lady Health Workers (LHWs) by 2005.
                                                    </p></div>

                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                    <div class="col-lg-4">
                        <!-- Courses Details Sidebar Start -->
                        <div class="sidebar">

                            <!-- Sidebar Widget Information Start -->
                            <div class="sidebar-widget widget-information">
                                <div class="info-price">
                                    <span class="price">Open</span>
                                </div>
                                <div class="info-list">
                                    <ul>
                                        <li><i class="icofont-certificate-alt-1"></i> <strong>Module</strong> <span>LHW Program</span></li>
                                        <li><i class="icofont-man-in-glasses"></i> <strong>Instruction Mode</strong> <span>Self Paced</span></li>
                                        <li><i class="icofont-ui-video-play"></i> <strong>Materials</strong> <span>Docs & Videos</span></li>
                                        <li><i class="icofont-bars"></i> <strong>Level</strong> <span>Basic to Advanced</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Language</strong> <span>English/Urdu</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Requirements</strong> <span>Basic Computer </br>Usage</span></li>
                                    </ul>
                                </div>
                                <div class="info-btn">
                                    <a href="#manuals" class="btn btn-primary btn-hover-dark">Start Now</a>
                                </div>
                            </div>
                            <!-- Sidebar Widget Information End -->

                        </div>
                        <!-- Courses Details Sidebar End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Courses End -->
        
        
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-12">

                        <!-- Courses Details Start -->
                        <div class="courses-details">


                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab"> 
                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="vidz">

                                            <!-- Tab Instructors Start -->
                                            <div class="tab-instructors">
                                                <div class="details-tab-menu">
                                                        <ul class="nav justify-content-left">
                                                                <h1>Tutorials & Training Videos</h1> 
                                                                <!--<li><button data-bs-toggle="tab" data-bs-target="#reviews">Reviews</button></li>-->
                                                        </ul>
                                                </div>

                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/1-LHW%20Digital%20Diary%20Android%20App%20Intro.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">LHW Digital Diary App Introduction</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/1-LHW%20Digital%20Diary%20-%20App%20intro.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">LHW Digital Diary App Introduction</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/2-how%20to%20update%20LHW%20digital%20diary%20App.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Updating LHW Digital Diary App</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/3-how%20to%20login%20LHW%20digital%20diary%20App.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">How to Login</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/3-how%20to%20login%20LHW%20digital%20diary%20App.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Registration & Editing Household members</p>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/4-household%20list.mp4" allowfullscreen="">
                                                               </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Household Listing and Options</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/4-shifting%20household.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Shifting of Household</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/4-how%20to%20delete%20household.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Deleting Household</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/5-family%20members%20list.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Family Member Listing - Explanation and Options</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/5-LHW%20Digital%20Diary%20-%20Adding-Editing-transfer%20Family%20members%20of%20households.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Editing and transfering household members</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/5-shifting%20due%20to%20marriage.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Family member shifting due to marriage</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/5-how%20to%20delete%20%20member.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Deleting Member of household</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/6-LHW%20Digital%20Diary%20-%20Main%20Dashboard%20-%20Intro.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Explanation of main Dashboard</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/6-dashboard%20%20explain.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Explanation of Dashboard - Detailed</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/7-upsynced%20downsynced%20stats.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Explanation of Data up - sync and down-sync status</p>
                                                        </div>
                                                    </div><div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/7-upsynced%20downsynced%20stats.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Explanation of Menu options</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/7-sidebar%20explain.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Sidebar Manu Explained</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/8-child%20list.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Child Listing - Explanation and Options</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/8-how%20to%20enter%20child%20data%20lhw%20digital%20diary%20App.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Entering Child Data</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/9-LHW%20Digital%20Diary%20-%20Child%20Growth%20Monitoring.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Child Growth Monitoring and vaccination information management</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/10-pregnant%20women%20list.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Pregnanat Women Listing and Options</p>
                                                        </div>
                                                    </div><div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/10-how%20to%20enter%20pregnant%20women%20data%20lhw%20digital%20diary%20App.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Entering Pregnant Women Data</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/11-LHW%20Digital%20Diary%20-%20Pregnant%20Women%20-%20visits%20and%20pregnancy%20information.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Pregnant Women - Visits and pregnancy information management</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/12-LHW%20Digital%20Diary%20-%20Use%20of%20different%20options.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Use of Diffrent options</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/13-extra%20meetings%20insertion%20lhw%20digital%20diary%20App.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Entering Extra Meeting</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/14-how%20to%20insert%20%20family%20planning.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Entering Family Planning</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/15-how%20to%20insert%20common%20ailments.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Entering Common Aliment</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/16-how%20to%20insert%20Logistics.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Entering Logistic</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/17-lhw%20toolkit%20insertion%20and%20updation.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Miscellaneous Items Logistic</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="http://lhwdiary.nhsrc.pk/training/videos/18-supervisory%20visit%20insertion%20and%20updation.mp4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Monthly visits of LHS and supervisors</p>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <!--</div>-->
                                                </div>
                                            </div>
                                            <!-- Tab Instructors End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                </div>
            </div>
        </div>
        
        <script>
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth',
//            speed: 2000
        });
    });
});
            </script>