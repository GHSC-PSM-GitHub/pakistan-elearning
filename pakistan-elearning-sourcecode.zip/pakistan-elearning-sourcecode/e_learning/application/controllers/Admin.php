<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
//        check_login_user();
        $this->load->model('Manuals_info');
        $this->load->model('locations');
        $this->manuals_info = new Manuals_info();
        $this->obj_location = new Locations();
    }
    
    public function add_manual() {
        if (!empty($_POST)) {
//            print_r($_POST);exit;
            if (isset($_POST['manual_id'])) {
                $this->manuals_info->pk_id = $_POST['manual_id'];
            }
            
            $this->manuals_info->manual_name = $_POST['manual_name'];
            $this->manuals_info->province_id = $_POST['province'];
            $this->manuals_info->user_level = $_POST['level'];
            $this->manuals_info->system_id = $_POST['system_id'];

            //file upload
            $uploadedFile = '';
            $uploadDir = 'uploads/';
            if (!empty($_FILES["fileToUpload"]["name"])) {
                    //                    $uploadedFile = 'test';
                    // File path config 
                    $fileName = basename($_FILES["fileToUpload"]["name"]);
                    $targetFilePath = $uploadDir . $fileName;
                    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

                    // Allow certain file formats 
                    $allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
                    if (in_array($fileType, $allowTypes)) {
                            // Upload file to the server 
                            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
                                    $uploadedFile = $fileName;
                            }
                    }
            }

            $this->manuals_info->manual_url = $uploadedFile;
            
            $file = $this->manuals_info->save();
            
            redirect(base_url() . 'admin/view_manual', 'refresh');
        } else {
            $province_id = 1;
            $lvl = 4;
            $result = $this->obj_location->find_by_parent_id($province_id, $lvl);
            $data['provinces'] = $this->obj_location->find_active()->result_array();
            
            $data['page_title'] = 'Add Manuals';
            $data['districts'] = $result;
            $data['main_content'] = $this->load->view('admin/add_manual', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }
    
    public function view_manual() {
        $data = array();
        $role = $this->session->userdata('role');
        
        $data['result'] = $this->manuals_info->find_all_info();
        
        $data['page_title'] = 'Manage Manuals';
        $data['main_content'] = $this->load->view('admin/view_manual', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function edit() {
        $manual_id = $_REQUEST['manualid'];
        $file = $this->manuals_info->find_by_id($manual_id);
        
        $data['result'] = $file->result_array();
        $data['manual_id'] = $manual_id;
        $data['page_title'] = 'Edit Manual';
        $province_id = 1;
        $lvl = 4;
        $result = $this->obj_location->find_by_parent_id($province_id, $lvl);
        
        $data['provinces'] = $this->obj_location->find_active()->result_array();

        $data['main_content'] = $this->load->view('admin/add_manual', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function all_manuals() {
        $data = array();
        $role = $this->session->userdata('role');
        
        $data['result'] = $this->manuals_info->find_all_info();
        
        $data['page_title'] = 'Manuals';
        $data['main_content'] = $this->load->view('admin/all_manuals', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
}
