<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Courses extends CI_Controller {
   // public function __construct() {
     //   parent::__construct();
        
        // $this->load->model('Manuals_info');
        // $this->manuals_info = new Manuals_info();
    //}
    
    public function clmis_course() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(3);
        $data['main_content'] = $this->load->view('courses/clmis_course', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
     public function idmis_course() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(3);
        $data['main_content'] = $this->load->view('courses/idmis_course', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
     public function vlmis_course() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(3);
        $data['main_content'] = $this->load->view('courses/vlmis_course', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    }