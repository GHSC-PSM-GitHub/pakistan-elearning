<style>
    #imgdesign {
        background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
        border:2px solid #b5e4cb;
            padding: 15px;
  margin: 8px;
    }
    #textdesign 
    {
         text-align: center;
/*        padding: 10px 20px;
        font-size:20px;
    font-weight:bold;*/
    }
.buttons {
  background-color: #309255; /* Green */
  border: none;
  color: white;
  padding: 2px 0px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 0px 0px;
  transition-duration: 0.4s;
  cursor: pointer;
  border-radius: 4px;
  height:25px;
  width: 70px;
}

.button1s {
  background-color: #309255; 
  color: #fff; 
  border: 2px solid #309255;
}

.button1s:hover {
  background-color: #52c47c;
  color: white;
}
</style>
        <!-- Mobile Menu Start -->
        
        <!-- Mobile Menu End -->

        <!-- Overlay Start -->
        <div class="overlay"></div>
        <!-- Overlay End -->

        <!-- Page Banner Start -->
        <div class="section page-banner">

            <img class="shape-1 animation-round" src="<?php echo base_url(); ?>assets/images/shape/shape-8.png" alt="Shape">

            <img class="shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-23.png" alt="Shape">

            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">Course Details</li>
                    </ul>
                    <h2 class="title">Course : <span> Covid-MIS</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="<?php echo base_url(); ?>assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>

                <img class="icon-shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-6.png" alt="Shape">

            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="<?php echo base_url(); ?>assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="<?php echo base_url(); ?>assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

        <!-- Courses Start -->
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-8">

                        <!-- Courses Details Start -->
                        <div class="courses-details">

                            <div class="courses-details-images" style="height:250px;">
                                <img src="<?php echo base_url(); ?>assets/images/courses/covid.jpg" alt="Courses Details">
                                <!--<span class="tags">Finance</span>-->

<!--                                <div class="courses-play" >
                                    <img src="<?php echo base_url(); ?>assets/images/courses/circle-shape.png" alt="Play">
                                    <a class="play video-popup" href="https://www.youtube.com/watch?v=Wif4ZkwC0AM"><i class="flaticon-play"></i></a>
                                </div>-->
                            </div>

                            <h2 class="title">COVID-LMIS</h2>

                            <div class="courses-details-admin">
                                <div class="admin-author">
                                    <div class="author-thumb">
                                        <img src="<?php echo base_url(); ?>assets/images/author/author-03.jpg" alt="Author">
                                    </div>
                                    <div class="author-content">
                                        <a class="name" href="#">GHSC-PSM</a>
                                    </div>
                                </div>
                            </div>

                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab">

                                <!-- Details Tab Menu End -->

                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    <h3 class="tab-title">Introduction:</h3>
                                                    <p>
                                                        Amid COVID-19, based on country-wide successful deployment of LMIS and the project’s inhouse capacity on digitization, COVID-MIS was developed and implemented to integrate information, collected through different web based and mobile applications on a single technology platform. The COVID-MIS supports different data sets and translates them into actionable information around COVID-19 vaccination and vaccines management through analytical dashboards. It has a pivotable role in effective response to supply chain system strengthening through covid vaccine data management, resource identifications, data analytics, warehouse management, distribution planning, forecasting & quantification, and reverse logistics.
                                                        <br><br>
                                                        The COVID-MIS plays a critical role for the healthcare organizations and governments in terms of preparedness as it provides a range of benefits based on vaccination distribution, coverage, monitoring the impact of interventions, and analyzing data to identify trends and patterns. This can help make more informed decisions and to respond more effectively to the pandemic.
                                                    </p></div>

                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                    <div class="col-lg-4">
                        <!-- Courses Details Sidebar Start -->
                        <div class="sidebar">

                            <!-- Sidebar Widget Information Start -->
                            <div class="sidebar-widget widget-information">
                                <div class="info-price">
                                    <span class="price">Open</span>
                                </div>
                                <div class="info-list">
                                    <ul>
                                        <li><i class="icofont-certificate-alt-1"></i> <strong>Module</strong> <span>COVID-LMIS</span></li>
                                        <li><i class="icofont-man-in-glasses"></i> <strong>Instruction Mode</strong> <span>Self Paced</span></li>
                                        <li><i class="icofont-ui-video-play"></i> <strong>Materials</strong> <span>Docs & Videos</span></li>
                                        <li><i class="icofont-bars"></i> <strong>Level</strong> <span>Basic to Advanced</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Language</strong> <span>English/Urdu</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Requirements</strong> <span>Basic Computer </br>Usage</span></li>
                                    </ul>
                                </div>
                                <div class="info-btn">
                                    <a href="#manuals" class="btn btn-primary btn-hover-dark">Start Now</a>
                                </div>
                            </div>
                            <!-- Sidebar Widget Information End -->

                        </div>
                        <!-- Courses Details Sidebar End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Courses End -->
        
        
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-12">

                        <!-- Courses Details Start -->
                        <div class="courses-details">


                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab"> 
                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="manuals">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    
                                                    <div class="col col-md-12">
                                        <div class="details-tab-menu">
                                    <ul class="nav justify-content-left">
                                        <h1>User &amp; Training Manuals</h1> 
                                        <!--<li><button data-bs-toggle="tab" data-bs-target="#reviews">Reviews</button></li>-->
                                    </ul>
                                </div>
                                        <br><br>
                                                                                        <h5>Covid LMIS User &amp; Training Manuals </h5>
<!--                                                <div class="row">
                                                    <div class="col-md-12 ">-->
                                                    <br>
                                                        <table class="table table-hover">
                                                            <tbody>
                                                                <tr>
                                                                    <td>1</td>
                                                                    <td class="doc-title">Covid LMIS Training Manual</td>
                                                                    <td class="doc-link">
                                                                        <a class="buttons button1s" target="_blank" href="http://lmis.gov.pk/docs/userandtrainingmanuals/covidlmis.pdf">Download</a>&nbsp;&nbsp;
                                                                       <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                        <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                    </td>
                                                                </tr>
                                                                
                                                                <?php $srno = 2;
                                                                if(isset($result) && !empty($result)) {
                                                                        foreach ($result->result_array() as $row) { ?>
                                                                            <tr>
                                                                                <td><?php echo $srno++; ?></td>
                                                                                <td class="doc-title"><?php echo $row['manual_name'] ?></td>
                                                                                <td class="doc-link">
                                                                                    <a class="buttons button1s" target="_blank" href="<?php echo base_url(); ?>uploads/<?php echo $row['manual_url']; ?>">Download</a>&nbsp;&nbsp;
                                                                                </td>
                                                                            </tr>
                                                                <?php } } ?>
                                                                    
                                                            </tbody>
                                                        </table>
<!--                                                    </div>
                                                </div>-->
                                                 
                                                                                        <br>

                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                        <div class="tab-pane show active" id="vidz">

                                            <!-- Tab Instructors Start -->
                                            <div class="tab-instructors">
                                                <div class="details-tab-menu">
                                                        <ul class="nav justify-content-left">
                                                                <h1>Tutorials & Training Videos</h1> 
                                                                <!--<li><button data-bs-toggle="tab" data-bs-target="#reviews">Reviews</button></li>-->
                                                        </ul>
                                                </div>

                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/xWcOaVt1I5g" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">COVID-19 NIH Inventory Management</p>
                                                        </div>
                                                    </div>  
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                                <iframe width="95%" height="200"  src="https://www.youtube.com/embed/MgKdiRoTWuE" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">COVID-19 NDMA Procurement and LMIS</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/KROJQMgGA44" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">COVID-19 NDMA LMIS</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/FkJpqipb928" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">COVID-19 Travelers Surveillance MIS</p>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/j-2yR6UFS68" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">COVID-19 Forecasting Calculator for PPE</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/FkAY8IpSRYw" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">Sindh COVID-19 Training Dashboard</p>
                                                        </div>
                                                    </div>                                           
                                                    <!--</div>-->
                                                </div>
                                            </div>
                                            <!-- Tab Instructors End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                </div>
            </div>
        </div>
        
        <script>
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth',
//            speed: 2000
        });
    });
});
            </script>