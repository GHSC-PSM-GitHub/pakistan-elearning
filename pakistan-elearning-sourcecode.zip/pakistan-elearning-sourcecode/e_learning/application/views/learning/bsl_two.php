<style>
    #imgdesign {
        background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
        border:2px solid #b5e4cb;
            padding: 15px;
  margin: 8px;
    }
    #textdesign 
    {
         text-align: center;
/*        padding: 10px 20px;
        font-size:20px;
    font-weight:bold;*/
    }
.buttons {
  background-color: #309255; /* Green */
  border: none;
  color: white;
  padding: 2px 0px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 0px 0px;
  transition-duration: 0.4s;
  cursor: pointer;
  border-radius: 4px;
  height:25px;
  width: 70px;
}

.button1s {
  background-color: #309255; 
  color: #fff; 
  border: 2px solid #309255;
}

.button1s:hover {
  background-color: #52c47c;
  color: white;
}
</style>
        <!-- Mobile Menu Start -->
        
        <!-- Mobile Menu End -->

        <!-- Overlay Start -->
        <div class="overlay"></div>
        <!-- Overlay End -->

        <!-- Page Banner Start -->
        <div class="section page-banner">

            <img class="shape-1 animation-round" src="<?php echo base_url(); ?>assets/images/shape/shape-8.png" alt="Shape">

            <img class="shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-23.png" alt="Shape">

            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">Course Details</li>
                    </ul>
                    <h2 class="title">Course :<span> BSL 2 Labs</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="<?php echo base_url(); ?>assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>

                <img class="icon-shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-6.png" alt="Shape">

            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="<?php echo base_url(); ?>assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="<?php echo base_url(); ?>assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

        <!-- Courses Start -->
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-8">

                        <!-- Courses Details Start -->
                        <div class="courses-details">

                            <div class="courses-details-images" style="height:250px;">
                                <img src="<?php echo base_url(); ?>assets/images/courses/bsl2.jpg" alt="Courses Details">
                                <!--<span class="tags">Finance</span>-->

<!--                                <div class="courses-play" >
                                    <img src="<?php echo base_url(); ?>assets/images/courses/circle-shape.png" alt="Play">
                                    <a class="play video-popup" href="https://www.youtube.com/watch?v=Wif4ZkwC0AM"><i class="flaticon-play"></i></a>
                                </div>-->
                            </div>

                            <h2 class="title">Pakistan Mobile Biosafty Level - 2 Labs</h2>

                            <div class="courses-details-admin">
                                <div class="admin-author">
                                    <div class="author-thumb">
                                        <img src="<?php echo base_url(); ?>assets/images/courses/bsl2_icon.png" alt="Author">
                                    </div>
                                    <div class="author-content">
                                        <a class="name" href="#">GHSC-PSM</a>
                                    </div>
                                </div>
                            </div>

                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab">

                                <!-- Details Tab Menu End -->

                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    <h3 class="tab-title">Introduction:</h3>
                                                    <p>
                                                        In geographical locations where diagnostic laboratory support is limited, infectious disease outbreaks such as the
                                                        current COVID-19 pandemic can result in exceptionally high infection rates. The use of mobile laboratories can
                                                        enhance the potential to detect, diagnose, and report any emerging infectious disease outbreak and inform public
                                                        health authorities so that they can respond appropriately to limit and prevent potential pathogen transmission.
                                                        Several resources were used to create this manual, National Health Vision Pakistan 2016–25, provincial health
                                                        strategies, National Biosafety and Biosecurity Policy,
                                                        3 and the World Health Organization (WHO) Laboratory
                                                        biosafety manual.
                                                        <br>
                                                        The purpose of this manual is to provide standardized guidelines on biosafety and biosecurity of mobile BSL-2
                                                        laboratories to enable and ensure maximum protection and monitoring against physical, biological, and
                                                        environmental hazards.
                                                        <br>
                                                        The manual is designed to:
                                                        <br>
                                                        ● Provide a safe working environment for mobile laboratory staff and related personnel
                                                        <br>
                                                        ● Protect mobile laboratory staff from possible biological hazards<br>
                                                        ● Strengthen mobile laboratories’ staff capacity in biosafety and biosecurity<br>
                                                        ● Minimize physical and biological risks in operating mobile BSL-2 laboratories
                                                    </p></div>

                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                    <div class="col-lg-4">
                        <!-- Courses Details Sidebar Start -->
                        <div class="sidebar">

                            <!-- Sidebar Widget Information Start -->
                            <div class="sidebar-widget widget-information">
                                <div class="info-price">
                                    <span class="price">Open</span>
                                </div>
                                <div class="info-list">
                                    <ul>
                                        <li><i class="icofont-certificate-alt-1"></i> <strong>Module</strong> <span>BSL-2 Lab</span></li>
                                        <li><i class="icofont-man-in-glasses"></i> <strong>Instruction Mode</strong> <span>Self Paced</span></li>
                                        <li><i class="icofont-ui-video-play"></i> <strong>Materials</strong> <span>Docs & Videos</span></li>
                                        <li><i class="icofont-bars"></i> <strong>Level</strong> <span>Basic to Advanced</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Language</strong> <span>English/Urdu</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Requirements</strong> <span>Basic Computer </br>Usage</span></li>
                                    </ul>
                                </div>
                                <div class="info-btn">
                                    <a href="#manuals" class="btn btn-primary btn-hover-dark">Start Now</a>
                                </div>
                            </div>
                            <!-- Sidebar Widget Information End -->

                        </div>
                        <!-- Courses Details Sidebar End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Courses End -->
        
        
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-12">

                        <!-- Courses Details Start -->
                        <div class="courses-details">


                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab"> 
                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="manuals">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    
                                                    <div class="col col-md-12">
                                        <div class="details-tab-menu">
                                    <ul class="nav justify-content-left">
                                        <h1>User &amp; Training Manuals</h1> 
                                        <!--<li><button data-bs-toggle="tab" data-bs-target="#reviews">Reviews</button></li>-->
                                    </ul>
                                </div>
                                        <br><br>
                                                                                        <h5>Pakistan Mobile Biosafty Level - 2 Labs User &amp; Training Manuals </h5>
<!--                                                <div class="row">
                                                    <div class="col-md-12 ">-->
                                                    <br>
                                                        <table class="table table-hover">
                                                            <tbody>
                                                                    <tr>
                                                                        <td>1</td>
                                                                        <td class="doc-title">Absorbance96 App software manual.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/Absorbance96 App software manual.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>2</td>
                                                                        <td class="doc-title">Absorbance96 Manual.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/Absorbance96 Manual.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>3</td>
                                                                        <td class="doc-title">Autoclave-SLEDD 3568 _ 4072.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/absorbance96setup.exe">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>4</td>
                                                                        <td class="doc-title">Balance BXX_User_manual_EN_10_2020.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/Autoclave-SLEDD 3568 _ 4072.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>5</td>
                                                                        <td class="doc-title">BIOBASE Electrophoresis Power Supply BPS User Manual 202007.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/Balance BXX_User_manual_EN_10_2020.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>6</td>
                                                                        <td class="doc-title">BIOBASE Horizontal Electrophoresis ET-H1 User Manual 202007.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/BIOBASE Electrophoresis Power Supply BPS User Manual 202007.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>7</td>
                                                                        <td class="doc-title">BIOBASE Micro-Volume UV_ VIS Spectrophotometer BK-CW2000 User Manual 202011.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/BIOBASE Horizontal Electrophoresis ET-H1 User Manual 202007.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>8</td>
                                                                        <td class="doc-title">BIOBASE Water Tank WT Series User Manual 202012.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/BIOBASE Micro-Volume UV_ VIS Spectrophotometer BK-CW2000 User Manual 202011.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>9</td>
                                                                        <td class="doc-title">E-C6-4.100CP User Manual.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/BIOBASE Water Tank WT Series User Manual 202012.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>10</td>
                                                                        <td class="doc-title">Eins-Sci QPCR Manual A.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/E-C6-4.100CP User Manual.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>11</td>
                                                                        <td class="doc-title">E-MS10S-H5-D Instructions V21.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/Eins-Sci QPCR Manual A.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>12</td>
                                                                        <td class="doc-title">EN-Bante210 Benchtop pH Meter.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/E-MS10S-H5-D Instructions V21.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>13</td>
                                                                        <td class="doc-title">E-PF-P Instructions V21.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/EN-Bante210 Benchtop pH Meter.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>14</td>
                                                                        <td class="doc-title">Fridge Freezer YCD-EL450.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/E-PF-P Instructions V21.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>15</td>
                                                                        <td class="doc-title">MicroPipettes Instructions V21.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/Fridge Freezer YCD-EL450.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>16</td>
                                                                        <td class="doc-title">MW9622 Operation Manual.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/MicroPipettes Instructions V21.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>17</td>
                                                                        <td class="doc-title">Tianlong - User Manual - Extraction Device.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/MW9622 Operation Manual.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>18</td>
                                                                        <td class="doc-title">Vortex E-VM-A Instructions V21.pdf</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/Tianlong - User Manual - Extraction Device.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>19</td>
                                                                        <td class="doc-title">Operations and
                                                                            Maintenance Manual
                                                                            Mobile Biosafety Level-2 labs - Pakistan
                                                                        </td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://drive.google.com/file/d/1Vj11-nsicZORsHNgDxF44X7SKYow8r68/view">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>20</td>
                                                                        <td class="doc-title">Mobile BSL-2 Manual 2022</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://lmis.gov.pk/bsl2/manuals/FinalMobileBSL-2manual.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <?php $srno = 21;
                                                                    if(isset($result) && !empty($result)) {
                                                                            foreach ($result->result_array() as $row) { ?>
                                                                                <tr>
                                                                                    <td><?php echo $srno++; ?></td>
                                                                                    <td class="doc-title"><?php echo $row['manual_name'] ?></td>
                                                                                    <td class="doc-link">
                                                                                        <a class="buttons button1s" target="_blank" href="<?php echo base_url(); ?>uploads/<?php echo $row['manual_url']; ?>">Download</a>&nbsp;&nbsp;
                                                                                    </td>
                                                                                </tr>
                                                                    <?php } } ?>
                                                                    
                                                                </tbody>
                                                        </table>
<!--                                                    </div>
                                                </div>-->
                                                 
                                                                                        <br>

                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                </div>
            </div>
        </div>
        
        <script>
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth',
//            speed: 2000
        });
    });
});
            </script>