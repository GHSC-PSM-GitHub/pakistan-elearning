<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>eLearning System</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/images/favicon.ico">

    <!-- CSS
	============================================ -->
    
    <!-- Google Fonts CSS -->  
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/icofont.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/font-awesome.min.css">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/animate.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/apexcharts.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins/jqvmap.min.css">

    <!-- Main Style CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->
    <!-- <link rel="stylesheet" href="assets/css/vendor/plugins.min.css">
    <link rel="stylesheet" href="assets/css/style.min.css"> -->

</head>

<body>

    <div class="main-wrapper">

        <!-- Header Section Start -->
        <div class="header-section">

            <!-- Header Top Start -->
            <div class="header-top d-none d-lg-block">
                <div class="container">

                    <!-- Header Top Wrapper Start -->
                    <div class="header-top-wrapper">

                        <!-- Header Top Left Start -->
                        <div class="header-top-left">
                            <p>Access all learning material and documentation related to :<a href="#">LMIS & IDMIS.</a></p>
                        </div>
                        <!-- Header Top Left End -->

                        <!-- Header Top Medal Start -->
                        <div class="header-top-medal">
                            <div class="top-info">
                                <!-- <p><i class="flaticon-phone-call"></i> <a href="tel:9702621413">(970) 262-1413</a></p> -->
                                <p><i class="flaticon-email"></i> <a href="mailto:support@lmis.gov.pk">support@lmis.gov.pk</a></p>
                            </div>
                        </div>
                        <!-- Header Top Medal End -->

                        <!-- Header Top Right Start -->
                        <div class="header-top-right">
                            <ul class="social">
                                <li><a href="https://www.linkedin.com/company/usaid-global-health-supply-chain-program-procurement-and-supply-management/"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="https://www.lmis.gov.pk"><i class="fa fa-globe"></i></a></li> 
                            </ul>
                        </div>
                        <!-- Header Top Right End -->

                    </div>
                    <!-- Header Top Wrapper End -->

                </div>
            </div>
            <!-- Header Top End -->

            <!-- Header Main Start -->
            <div class="header-main">
                <div class="container">

                    <!-- Header Main Start -->
                    <div class="header-main-wrapper">

                        <!-- Header Logo Start -->
                        <div class="header-logo">
                              
                                <a href="<?php echo base_url(); ?>">
                              <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo"></a>
								<img style="width:70px;height:60px;margin-right: 100px;" src="<?php echo base_url(); ?>assets/images/fed.png" alt="GOP">
                        </div>
                        <!-- Header Logo End -->

                        <!-- Header Menu Start -->
                        <div class="header-menu d-none d-lg-block">
                            <ul class="nav-menu">
                                <li><a href="<?php echo base_url();?>">Home</a></li>
                                <li>
                                    <a href="#">All Modules</a>
                                    <ul class="sub-menu">
                                        <li><a href="<?php echo base_url(); ?>Learning/idmis">IDMIS</a></li>
                                        <li><a href="<?php echo base_url(); ?>Learning/vlmis">vLMIS</a></li>
                                        <li><a href="<?php echo base_url(); ?>Learning/clmis">cLMIS</a></li>
                                        <li><a href="<?php echo base_url(); ?>Learning/ecr">ECR</a></li>
                                        <li><a href="<?php echo base_url(); ?>Learning/covid_mis">Covid-MIS</a></li>
                                        <li><a href="<?php echo base_url(); ?>Learning/bsl_two">BSL-2</a></li>
                                        <li><a href="<?php echo base_url(); ?>Learning/lhw_digital_diary">LHW Digital Diary</a></li>
                                    </ul>
      
                                </li>
                                 <li>
                                    <a href="#">COURSE</a>
                                    <ul class="sub-menu">
                                        <li><a href="<?php echo base_url(); ?>Courses/idmis_course">IDMIS</a></li>
                                        <li><a href="<?php echo base_url(); ?>Courses/vlmis_course">vLMIS</a></li>
                                        <li><a href="<?php echo base_url(); ?>Courses/clmis_course">cLMIS</a></li>
                                       
                                    </ul>
      
                                </li>
                            </ul>
                            

                        </div>
                        <!-- Header Menu End -->

                        <!-- Header Sing In & Up Start -->
                        <!--<div class="header-sign-in-up d-none d-lg-block">
                            <ul>
                                <li><a class="sign-in" href="login.html">Sign In</a></li>
                                <li><a class="sign-up" href="register.html">Sign Up</a></li>
                            </ul>
                        </div>-->
                        <!-- Header Sing In & Up End -->

                        <!-- Header Mobile Toggle Start -->
                        <div class="header-toggle d-lg-none">
                            <a class="menu-toggle" href="javascript:void(0)">
                                <span></span>
                                <span></span>
                                <span></span>
                            </a>
                        </div>
                        <!-- Header Mobile Toggle End -->

                    </div>
                    <!-- Header Main End -->

                </div>
            </div>
            <!-- Header Main End -->

        </div>
        <!-- Header Section End -->
		
		<div class="mobile-menu">

            <!-- Menu Close Start -->
            <a class="menu-close" href="javascript:void(0)">
                <i class="icofont-close-line"></i>
				
            </a>
            <!-- Menu Close End -->

            <!-- Mobile Top Medal Start -->
            <div class="mobile-top">
			 
                            
                       
                <p><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo"></a>
                </p>
                <p>
				<i class="flaticon-email"></i> <a href="mailto:support@lmis.gov.pk">support@lmis.gov.pk</a></p>
            </div>
            <!-- Mobile Top Medal End -->

        
            <!-- Mobile Sing In & Up End -->

            <!-- Mobile Menu Start -->
			
            <div class="mobile-menu-items">
                <ul class="nav-menu">
                    <li><a href="<?php echo base_url();?>">Home</a></li>
					<li><a href="<?php echo base_url(); ?>Learning/idmis">IDMIS</a></li>
					<li><a href="<?php echo base_url(); ?>Learning/vlmis">vLMIS</a></li>
					<li><a href="<?php echo base_url(); ?>Learning/clmis">cLMIS</a></li>
					<li><a href="<?php echo base_url(); ?>Learning/ecr">ECR</a></li>
					<li><a href="<?php echo base_url(); ?>Learning/covid_mis">Covid-MIS</a></li>
					<li><a href="<?php echo base_url(); ?>Learning/bsl_two">BSL-2</a></li>
                                        <li><a href="<?php echo base_url(); ?>Learning/lhw_digital_diary">LHW Digital Diary</a></li>
                </ul>

            </div>
            <!-- Mobile Menu End -->

            <!-- Mobile Menu End -->
            <div class="mobile-social">
                <ul class="social">
                    <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                </ul>
            </div>
            <!-- Mobile Menu End -->

        </div>