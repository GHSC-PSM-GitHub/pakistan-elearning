<style>
    #imgdesign {
        background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
        border:2px solid #b5e4cb;
            padding: 15px;
  margin: 8px;
    }
    #textdesign 
    {
         text-align: center;
/*        padding: 10px 20px;
        font-size:20px;
    font-weight:bold;*/
    }
.buttons {
  background-color: #309255; /* Green */
  border: none;
  color: white;
  padding: 2px 0px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 0px 0px;
  transition-duration: 0.4s;
  cursor: pointer;
  border-radius: 4px;
  height:25px;
  width: 70px;
}

.button1s {
  background-color: #309255; 
  color: #fff; 
  border: 2px solid #309255;
}

.button1s:hover {
  background-color: #52c47c;
  color: white;
}
</style>
        <!-- Mobile Menu Start -->
        
        <!-- Mobile Menu End -->

        <!-- Overlay Start -->
        <div class="overlay"></div>
        <!-- Overlay End -->

        <!-- Page Banner Start -->
        <div class="section page-banner">

            <img class="shape-1 animation-round" src="<?php echo base_url(); ?>assets/images/shape/shape-8.png" alt="Shape">

            <img class="shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-23.png" alt="Shape">

            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">Course Details</li>
                    </ul>
                    <h2 class="title">Course : <span> cLMIS</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="<?php echo base_url(); ?>assets/images/shape/shape-5.png" alt="Shape">

                
                    <div class="box-wrapper">
                        <img class="icon-shape-2"<img style="width:100px;height:100px;margin-left: 20px;" src="<?php echo base_url(); ?>assets/images/fed.png" alt="Shape">
                    </div>
               

                <img class="icon-shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-6.png" alt="Shape">

            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="<?php echo base_url(); ?>assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="<?php echo base_url(); ?>assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

        <!-- Courses Start -->
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-8">

                        <!-- Courses Details Start -->
                        <div class="courses-details">

                            <div class="courses-details-images" style="height:250px;">
                                <img src="<?php echo base_url(); ?>assets/images/courses/courses-details.jpg" alt="Courses Details">
                                <!--<span class="tags">Finance</span>-->

<!--                                <div class="courses-play" >
                                    <img src="<?php echo base_url(); ?>assets/images/courses/circle-shape.png" alt="Play">
                                    <a class="play video-popup" href="https://www.youtube.com/watch?v=Wif4ZkwC0AM"><i class="flaticon-play"></i></a>
                                </div>-->
                            </div>

                            <h2 class="title">Contraceptive Logistic Management Information System.</h2>

                            <div class="courses-details-admin">
                                <div class="admin-author">
                                    <div class="author-thumb">
                                        <img src="<?php echo base_url(); ?>assets/images/author/author-01.jpg" alt="Author">
                                    </div>
                                    <div class="author-content">
                                        <a class="name" href="#">GHSC-PSM</a><img style="width:100px;height:100px;margin-right: 20px;" src="<?php echo base_url(); ?>assets/images/fed.png" alt="GOP">
                                    </div>
                                </div>
                            </div>

                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab">

                                <!-- Details Tab Menu End -->

                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    <h3 class="tab-title">Introduction:</h3>
                                                    <p>
                                                        Information is the center of the logistics cycle. Without information, the logistics system cannot be managed effectively. The web-based logistics management information system (LMIS) is designed in the context of health and population sector’s logistics information requirements of Pakistan, particularly in the post-devolution scenario of provincial health and population programs. The system brings in district-level reporting by using paper-based reports to aggregate facility-level data. With a unified system for reporting and requisitioning, the web based LMIS system can integrate information from all levels and sectors.
                                                        <br><br>
                                                        The Contraceptive Logistics Management Information System (cLMIS) was developed in 2011 with the support of USAID. The system contains modules on inventory management, consumption reporting, forecasting and supply planning, procurement planning, dashboards, and analytics. The real-time inventory management is being implemented at all levels. The system provides the users with projections to determine provincial requirements, develop forecasts, and secure financing for contraceptive procurement.
                                                        <br><br>
                                                        The FP data visibility also contributed to improved commodity security at the last mile. The cLMIS data visibility plays a significant role in improving stock monitoring at the district and sub-district level. Therefore, timely and accurate data entry and submission of monthly reports at the district level are critical to the functioning of the cLMIS. The data collected from the LMIS can then subsequently be used at each level of the supply chain to enhance informed decision making to meet service delivery demands.
                                                    </p></div>

                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                    <div class="col-lg-4">
                        <!-- Courses Details Sidebar Start -->
                        <div class="sidebar">

                            <!-- Sidebar Widget Information Start -->
                            <div class="sidebar-widget widget-information">
                                <div class="info-price">
                                    <span class="price">Open</span>
                                </div>
                                <div class="info-list">
                                    <ul>
                                        <li><i class="icofont-certificate-alt-1"></i> <strong>Module</strong> <span>cLMIS</span></li>
                                        <li><i class="icofont-man-in-glasses"></i> <strong>Instruction Mode</strong> <span>Self Paced</span></li>
                                        <li><i class="icofont-ui-video-play"></i> <strong>Materials</strong> <span>Docs & Videos</span></li>
                                        <li><i class="icofont-bars"></i> <strong>Level</strong> <span>Basic to Advanced</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Language</strong> <span>English/Urdu</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Requirements</strong> <span>Basic Computer </br>Usage</span></li>
                                    </ul>
                                </div>
                                <div class="info-btn">
                                    <a href="#manuals" class="btn btn-primary btn-hover-dark">Start Now</a>
                                </div>
                            </div>
                            <!-- Sidebar Widget Information End -->


                        </div>
                        <!-- Courses Details Sidebar End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Courses End -->
        
        
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-12">

                        <!-- Courses Details Start -->
                        <div class="courses-details">


                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab"> 
                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="manuals">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    
                                                    <div class="col col-md-12">
                                        <div class="details-tab-menu">
                                    <ul class="nav justify-content-left">
                                        <h1>User &amp; Training Manuals</h1> 
                                        <!--<li><button data-bs-toggle="tab" data-bs-target="#reviews">Reviews</button></li>-->
                                    </ul>
                                </div>
                                        <br><br>
                                                                                        <h5>Contraceptive Logistics Management Information System User &amp; Training Manuals </h5>
<!--                                                <div class="row">
                                                    <div class="col-md-12 ">-->
                                                    <br>
                                                        <table class="table table-hover">
                                                            <tbody>
                                                                                                                                    <tr>
                                                                        <td>1</td>
                                                                        <td class="doc-title">cLMIS - Facilitator Manual</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="http://lmis.gov.pk/docs/training_manuals/clmis_user_&amp;_training_manuals/clmis_facilitator_manual_updated.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>2</td>
                                                                        <td class="doc-title">cLMIS - Participants Guide</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="http://lmis.gov.pk/docs/training_manuals/clmis_user_&amp;_training_manuals/clmis_participants_guide_updated.pdf">Download</a></td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>3</td>
                                                                        <td class="doc-title">cLMIS - TOT Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="http://lmis.gov.pk/docs/training_manuals/clmis_user_&amp;_training_manuals/clmis_tot_manual_updated.pdf">Download</a></td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>4</td>
                                                                        <td class="doc-title">cLMIS - PWD - User Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="http://lmis.gov.pk/docs/training_manuals/clmis_user_&amp;_training_manuals/clmis_pwd_user_manual_updated.pdf">Download</a></td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>5</td>
                                                                        <td class="doc-title">cLMIS - User Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="http://lmis.gov.pk/docs/training_manuals/clmis_user_&amp;_training_manuals/clmis_user_manual_updated.pdf">Download</a></td>
                                                                    </tr>
                                                                    
                                                                    <?php $srno = 6;
                                                                    if(isset($result) && !empty($result)) {
                                                                            foreach ($result->result_array() as $row) { ?>
                                                                                <tr>
                                                                                    <td><?php echo $srno++; ?></td>
                                                                                    <td class="doc-title"><?php echo $row['manual_name'] ?></td>
                                                                                    <td class="doc-link">
                                                                                        <a class="buttons button1s" target="_blank" href="<?php echo base_url(); ?>uploads/<?php echo $row['manual_url']; ?>">Download</a>&nbsp;&nbsp;
                                                                                    </td>
                                                                                </tr>
                                                                    <?php } } ?>
                                                                    
                                                                </tbody>
                                                        </table>
<!--                                                    </div>
                                                </div>-->
                                                 
                                                                                        <br>

                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                        <div class="tab-pane show active" id="vidz">

                                            <!-- Tab Instructors Start -->
                                            <div class="tab-instructors">
											<div class="details-tab-menu">
												<ul class="nav justify-content-left">
													<h1>Tutorials & Training Videos</h1> 
													<!--<li><button data-bs-toggle="tab" data-bs-target="#reviews">Reviews</button></li>-->
												</ul>
											</div>

                                                <div class="row">
                                                    
                                                    
                                                    
                                                    
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/u3ueCS446_Y" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Learning basics of BI Tool</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/g60Me6zL12o" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - How to Receive Stock (English)</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/Q9Mj0GESMmw" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - How to Issue Stock (English)</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/LvJkXDN853E" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Stock and Batch Management(English)</p>
                                                        </div>
                                                    </div>
                                                     <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/B16iK07xXaM" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Stock and Batch Management(URDU)</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/qd511hZSWV0" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - How to Receive Stock (URDU)</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/mBssH1emVeE" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - How to Issue Stock (URDU)</p>
                                                        </div>
                                                    </div>
                                                   

                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/xWcOaVt1I5g" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - COVID-19 NIH Inventory Management</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/BTF9uJUrNCY" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Consumption Reporting Health Facility(URDU)</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/jHHskE9L19Q" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Stock Adjustment(URDU)</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/VDR6Qnkawh4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Consumption Reporting Health Facility(English)</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/sYvLSM6dHtI" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Stock Adjustment(English)</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                                <iframe width="95%" height="100"  src="https://www.youtube.com/embed/MF3_OZGPZ00" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Learning Management Information System Introduction</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="125"  src="https://www.youtube.com/embed/PfFdMESYC28" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - complete tutorial of Inventory Management</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="100"  src="https://www.youtube.com/embed/FNgA7cM1wJE" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">cLMIS - Learning Management Information System Executive Dashboard</p>
                                                        </div>
                                                    </div>
                                                    <!--</div>-->
                                                </div>
                                            </div>
                                            <!-- Tab Instructors End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                </div>
            </div>
        </div>
        

        <script>
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth',
//            speed: 2000
        });
    });
});
            </script>