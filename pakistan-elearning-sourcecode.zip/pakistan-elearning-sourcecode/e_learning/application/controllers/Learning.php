<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Learning extends CI_Controller {
    //public function __construct() {
      //  parent::__construct();
        
        // $this->load->model('Manuals_info');
        // $this->manuals_info = new Manuals_info();
    //}

    public function clmis() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(3);
        $data['main_content'] = $this->load->view('learning/clmis', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function vlmis() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(2);
        $data['main_content'] = $this->load->view('learning/vlmis', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function idmis() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(1);
        $data['main_content'] = $this->load->view('learning/idmis', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function ecr() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(4);
        $data['main_content'] = $this->load->view('learning/ecr', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function covid_mis() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(5);
        $data['main_content'] = $this->load->view('learning/covid_mis', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function bsl_two() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(6);
        $data['main_content'] = $this->load->view('learning/bsl_two', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function lhw_digital_diary() {
//        print_r('sdf');exit;
        $data['page_title'] = 'Courses Details';
        
        $data['result'] = array();
        // $data['result'] = $this->manuals_info->find_manuals_usingid(5);
        $data['main_content'] = $this->load->view('learning/lhw_digital_diary', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function show_file($filename = NULL){
		$file = 'assets/files/' . $filename;
		$data['file'] = $file;
		$this->load->view('learning/show_file', $data);
	}//end show function
}