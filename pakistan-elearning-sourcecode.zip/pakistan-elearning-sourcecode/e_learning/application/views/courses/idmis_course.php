<style>
    #imgdesign {
        background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
        border:2px solid #b5e4cb;
            padding: 15px;
  margin: 8px;
    }
    #textdesign 
    {
         text-align: center;
/*        padding: 10px 20px;
        font-size:20px;
    font-weight:bold;*/
    }
.buttons {
  background-color: #309255; /* Green */
  border: none;
  color: white;
  padding: 2px 0px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 0px 0px;
  transition-duration: 0.4s;
  cursor: pointer;
  border-radius: 4px;
  height:25px;
  width: 70px;
}

.button1s {
  background-color: #309255; 
  color: #fff; 
  border: 2px solid #309255;
}

.button1s:hover {
  background-color: #52c47c;
  color: white;
}
</style>
        <!-- Mobile Menu Start -->
        
        <!-- Mobile Menu End -->

        <!-- Overlay Start -->
        <div class="overlay"></div>
        <!-- Overlay End -->

        <!-- Page Banner Start -->
        <div class="section page-banner">

            <img class="shape-1 animation-round" src="<?php echo base_url(); ?>assets/images/shape/shape-8.png" alt="Shape">

            <img class="shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-23.png" alt="Shape">

            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">Course Details</li>
                    </ul>
                    <h2 class="title">Course :<span> IDMIS</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="<?php echo base_url(); ?>assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>

                <img class="icon-shape-2" src="<?php echo base_url(); ?>assets/images/shape/shape-6.png" alt="Shape">

            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="<?php echo base_url(); ?>assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="<?php echo base_url(); ?>assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

        <!-- Courses Start -->
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-8">

                        <!-- Courses Details Start -->
                        <div class="courses-details">

                            <div class="courses-details-images" style="height:350px;">
                                <img src="<?php echo base_url(); ?>assets/images/courses/idmis.jpg" alt="Courses Details">
                                <!--<span class="tags">Finance</span>-->

<!--                                <div class="courses-play" >
                                    <img src="<?php echo base_url(); ?>assets/images/courses/circle-shape.png" alt="Play">
                                    <a class="play video-popup" href="https://www.youtube.com/watch?v=Wif4ZkwC0AM"><i class="flaticon-play"></i></a>
                                </div>-->
                            </div>

                            <h2 class="title">Infectious Diseases Management Information System.</h2>

                            <div class="courses-details-admin">
                                <div class="admin-author">
                                    <div class="author-thumb">
                                        <img src="<?php echo base_url(); ?>assets/images/author/author-03.jpg" alt="Author">
                                    </div>
                                    <div class="author-content">
                                        <a class="name" href="#">GHSC-PSM</a>
                                    </div>
                                </div>
                            </div>

                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab">

                                <!-- Details Tab Menu End -->

                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    <h3 class="tab-title">Introduction:</h3>
                                                    <p>
                                                        USAID | Global Health Supply Chain Program – Procurement and Supply Management (GHSC PSM) Project, Pakistan was tasked by the Government of Pakistan with implementing a Infectious Diseases Management Information System (IDMIS) for Infectious Diseases using a web-based approach to facilitate country-wide data entry without the installation of any specific software. After several months of thorough consultations with all stakeholders from the public and private sectors, IDMIS was contextualized to the local stakeholder structure and the devolution of responsibility from the national to the provincial and district level.
                                                        <br><br>
                                                        The rise and rise of infectious diseases compel to adopt and utilize management information
                                                        system for successful monitoring and analyzing information related to infectious diseases.<br><br>
                                                        Therefore, the Infectious Diseases Management Information System (IDMIS) is the need of the hour and plays a vital role in successful management and monitoring of those affected by infectious diseases.
                                                        <br><br>
                                                        The motivation behind the use of the Infectious Disease Management System is to lessen the administrative cost associated with data collection and analysis. <br><br>This Infectious Diseases Management Information System is developed to ensure the following:<br>
                                                        ● Cost effectiveness by means of open-source software licensing<br>
                                                        ● Centralized mechanism of ensuring collection and monitoring of all infectious disease management data<br>
                                                        ● Automate the process, introducing a mechanism for decision support as per treatment guidelines<br>
                                                        ● Provide comprehensive reporting capabilities<br>
                                                        ● Maintain a user-friendly interface
                                                        <br><br>
                                                        IDMIS has the flexibility to integrate other health related diseases. In addition to the public sector, this application is also able to record national data of diseases of the private sector as well. The system contains modules on inventory management, consumption reporting, forecasting and supply planning, EMR, dashboards, and analytics. The IDMIS data visibility plays a significant role in improving stock monitoring at the district and facility level. The data collected from the IDMIS can then subsequently be used at each level of the supply chain to enhance informed decision making to meet service delivery demands.
                                                    </p></div>

                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                    <div class="col-lg-4">
                        <!-- Courses Details Sidebar Start -->
                        <div class="sidebar">

                            <!-- Sidebar Widget Information Start -->
                            <div class="sidebar-widget widget-information">
                                <div class="info-price">
                                    <span class="price">Open</span>
                                </div>
                                <div class="info-list">
                                    <ul>
                                        <li><i class="icofont-certificate-alt-1"></i> <strong>Module</strong> <span>IDMIS</span></li>
                                        <li><i class="icofont-man-in-glasses"></i> <strong>Instruction Mode</strong> <span>Self Paced</span></li>
                                        <li><i class="icofont-ui-video-play"></i> <strong>Materials</strong> <span>Docs & Videos</span></li>
                                        <li><i class="icofont-bars"></i> <strong>Level</strong> <span>Basic to Advanced</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Language</strong> <span>English/Urdu</span></li>
                                        <li><i class="icofont-book-alt"></i> <strong>Requirements</strong> <span>Basic Computer </br>Usage</span></li>
                                    </ul>
                                </div>
                                <div class="info-btn">
                                    <a href="#manuals" class="btn btn-primary btn-hover-dark">Start Now</a>
                                </div>
                            </div>
                            <!-- Sidebar Widget Information End -->

                        </div>
                        <!-- Courses Details Sidebar End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Courses End -->
        
        
        <div class="section section-padding mt-n10">
            <div class="container">
                <div class="row gx-10">
                    <div class="col-lg-12">

                        <!-- Courses Details Start -->
                        <div class="courses-details">


                            <!-- Courses Details Tab Start -->
                            <div class="courses-details-tab"> 
                                <!-- Details Tab Content Start -->
                                <div class="details-tab-content">
                                    <div class="tab-content">
                                        <div class="tab-pane show active" id="manuals">

                                            <!-- Tab Description Start -->
                                            <div class="tab-description">
                                                <div class="description-wrapper">
                                                    
                                                    <div class="col col-md-12">
                                        <div class="details-tab-menu">
                                    <ul class="nav justify-content-left">
                                        <h1>User &amp; Training Manuals</h1> 
                                        <!--<li><button data-bs-toggle="tab" data-bs-target="#reviews">Reviews</button></li>-->
                                    </ul>
                                </div>
                                        <br><br>
                                                                                        <h5>Infectious Diseases Management Information System User &amp; Training Manuals </h5>
<!--                                                <div class="row">
                                                    <div class="col-md-12 ">-->
                                                    <br>
                                                        <table class="table table-hover">
                                                            <tbody>
                                                                    <tr>
                                                                        <td>1</td>
                                                                        <td class="doc-title">IDMIS - Admin Manual</td>
                                                                        <td class="doc-link">
                                                                            <a class="buttons button1s" target="_blank" href="https://idmis.gov.pk/uploads/admin_manual.pdf">Download</a>&nbsp;&nbsp;
                                                                           <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'about.jpg' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Img', 40, '<br>') . '</a>'; ?>&nbsp;&nbsp;
                                                                            <?php // echo '<a onclick="window.open(\'' . base_url() . 'learning/show_file/' . 'MRF.xlsx' . '\',\'ShowDoc\',\'width=1100,height=700\')" class="buttons button1s">' . wordwrap('View Excel', 40, '<br>') . '</a>'; ?>
                                                                        </td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>2</td>
                                                                        <td class="doc-title">IDMIS - COVID Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="https://idmis.gov.pk/uploads/user_manual.pdf">Download</a></td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>3</td>
                                                                        <td class="doc-title">IDMIS - Provincial Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="https://idmis.gov.pk/uploads/provincial_manual.pdf">Download</a></td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>4</td>
                                                                        <td class="doc-title">IDMIS - District Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="https://idmis.gov.pk/uploads/district_manual.pdf">Download</a></td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>5</td>
                                                                        <td class="doc-title">IDMIS - CMU Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="https://idmis.gov.pk/uploads/cmu_manual.pdf">Download</a></td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>6</td>
                                                                        <td class="doc-title">IDMIS - Facility Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="https://idmis.gov.pk/uploads/hepatitis_emr_manual.pdf">Download</a></td>
                                                                    </tr>
                                                                                                                                        <tr>
                                                                        <td>7</td>
                                                                        <td class="doc-title">IDMIS - Reports Manual</td>
                                                                        <td class="doc-link"><a class="buttons button1s" target="_blank" href="https://idmis.gov.pk/uploads/reports_manual.pdf">Download</a></td>
                                                                    </tr>
                                                                    
                                                                    <?php $srno = 8;
                                                                    if(isset($result) && !empty($result)) {
                                                                            foreach ($result->result_array() as $row) { ?>
                                                                                <tr>
                                                                                    <td><?php echo $srno++; ?></td>
                                                                                    <td class="doc-title"><?php echo $row['manual_name'] ?></td>
                                                                                    <td class="doc-link">
                                                                                        <a class="buttons button1s" target="_blank" href="<?php echo base_url(); ?>uploads/<?php echo $row['manual_url']; ?>">Download</a>&nbsp;&nbsp;
                                                                                    </td>
                                                                                </tr>
                                                                    <?php } } ?>
                                                                    
                                                                </tbody>
                                                        </table>
<!--                                                    </div>
                                                </div>-->
                                                 
                                                                                        <br>

                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <!-- Tab Description End -->

                                        </div>
                                        <div class="tab-pane show active" id="vidz">

                                            <!-- Tab Instructors Start -->
                                            <div class="tab-instructors">
											<div class="details-tab-menu">
												<ul class="nav justify-content-left">
													<h1>Tutorials & Training Videos</h1> 
													<!--<li><button data-bs-toggle="tab" data-bs-target="#reviews">Reviews</button></li>-->
												</ul>
											</div>

                                                <div class="row">
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                                <iframe width="95%" height="200"  src="https://www.youtube.com/embed/feq0nWevpNY" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">IDs MIS - Opening Balances</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/QvpWxoJPX6I" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">IDs MIS Stock Issue to Centers</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/RQ5WozQe2ZM" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">IDs MIS Stock Receive Warehouse</p>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/39-gl9U6WQ4" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">IDs MIS Stock Issue to Facility</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/PAZ7AA4WLgc" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">IDs MIS Batch Management</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/3ROjDknDTkk" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">IDs MIS Requisition</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-4">
                                                        <!-- Single Courses Start -->
                                                        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
                                                            <div class="courses-images">
                                                               <iframe width="95%" height="200"  src="https://www.youtube.com/embed/CvwmGAZi7SI" allowfullscreen="">
                                                                </iframe>
                                                            </div>
                                                            <p id="textdesign" class="text-center">IDs MIS Consumption Form</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <!--</div>-->
                                                </div>
                                            </div>
                                            <!-- Tab Instructors End -->

                                        </div>
                                    </div>
                                </div>
                                <!-- Details Tab Content End -->

                            </div>
                            <!-- Courses Details Tab End -->

                        </div>
                        <!-- Courses Details End -->

                    </div>
                </div>
            </div>
        </div>
        
        <script>
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth',
//            speed: 2000
        });
    });
});
            </script>