<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {
    public function __construct() {
        parent::__construct();
    }

    function index() {

        $data['page_title'] = 'Main';

        $data['main_content'] = $this->load->view('index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function courses_details() {
        print_r('xyz');exit;
        $data['page_title'] = 'Courses Details';

        $data['main_content'] = $this->load->view('courses-details', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
}
