
        <!-- Mobile Menu End -->

        <!-- Overlay Start -->
        <div class="overlay"></div>
        <!-- Overlay End -->

        <!-- Slider Start -->
        <div class="section slider-section">

            <!-- Slider Shape Start -->
            <div class="slider-shape">
                <img class="shape-1 animation-round" src="assets/images/shape/shape-8.png" alt="Shape">
            </div>
            <!-- Slider Shape End -->

            <div class="container">

                <!-- Slider Content Start -->
                <div class="slider-content">
                    <h4 class="sub-title">eLearning System</h4>
                    <h2 class="main-title">Start your learning endeavour to look into <span>Logistics & Infectious Disease Systems.</span></h2>
                    <p>In depth training modules, tailored to cover all aspects of routine usage of systems.</p>
                    <a class="btn btn-primary btn-hover-dark" href="#start">Start Learning</a>
                </div>
                <!-- Slider Content End -->

            </div>

            <!-- Slider Courses Box Start -->
            <div class="slider-courses-box">

                <img class="shape-1 animation-left" src="assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-open-book"></i>
                        <span class="count">Manuals</span>
                         <p></p> 
                    </div>
                </div>

                <img class="shape-2" src="assets/images/shape/shape-6.png" alt="Shape">

            </div>
            <!-- Slider Courses Box End -->

            <!-- Slider Rating Box Start -->
            <div class="slider-rating-box">

                <div class="box-rating">
                    <div class="box-wrapper">
                        <span class="count">Videos  </span>
                        <p>Step by step Demos</p>
                    </div>
                </div>

                <img class="shape animation-up" src="assets/images/shape/shape-7.png" alt="Shape">

            </div>
            <!-- Slider Rating Box End -->

            <!-- Slider Images Start -->
            <div class="slider-images">
                <div class="images">
                    <img style="border-radius: 48%;" src="assets/images/slider/slider-1.png" alt="Slider">
                </div>
            </div>
            <!-- Slider Images End -->

            <!-- Slider Video Start -->
            <div class="slider-video">
                <img class="shape-1" src="assets/images/shape/shape-9.png" alt="Shape">

                <div class="video-play">
                    <img src="assets/images/shape/shape-10.png" alt="Shape">
                    <a href="https://www.youtube.com/watch?v=BRvyWfuxGuU" class="play video-popup"><i class="flaticon-play"></i></a>
                </div>
            </div>
            <!-- Slider Video End -->

        </div>
        <!-- Slider End -->

        <!-- Brand Logo Start -->
        <div class="section section-padding-02">
            <div class="container">

                <!-- Brand Logo Wrapper Start -->
                <div class="brand-logo-wrapper">

                    <img class="shape-1" src="assets/images/shape/shape-19.png" alt="Shape">

                    <img class="shape-2 animation-round" src="assets/images/shape/shape-20.png" alt="Shape">

                    <!-- Section Title Start -->
                    <!--<div class="section-title shape-03">
                        <h2 class="main-title">Best Supporter of <span> Edule.</span></h2>
                    </div>-->
                    <!-- Section Title End -->

                    <!-- Brand Logo Start -->
                    <div class="brand-logo brand-active">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">


                                <div class="single-brand swiper-slide">
                                    <img src="assets/images/brand/brand-06.png" alt="Brand">
                                </div>
                                <div class="single-brand swiper-slide">
                                    <img src="assets/images/brand/nih.png" alt="Brand" style="width:86px;height:90px;">
                                </div>

                                <!-- Single Brand Start -->
                                <div class="single-brand swiper-slide">
                                    <img src="assets/images/brand/brand-02.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->

                                <!-- Single Brand Start -->
                                <div class="single-brand swiper-slide">
                                    <img src="assets/images/brand/brand-03.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->

                                <!-- Single Brand Start -->
                                <div class="single-brand swiper-slide">
                                    <img src="assets/images/brand/brand-04.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->

                                <!-- Single Brand Start -->
                                <div class="single-brand swiper-slide">
                                    <img src="assets/images/brand/brand-05.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->


                            </div>
                        </div>
                    </div>
                    <!-- Brand Logo End -->

                </div>
                <!-- Brand Logo Wrapper End -->

            </div>
        </div>
        <!-- Brand Logo End -->

        <!-- All Courses Start -->
        <div id="start" class="section section-padding-02">
            <div class="container">

                <!-- All Courses Top Start -->
                <div class="courses-top">

                    <!-- Section Title Start -->
                    <div class="section-title shape-01">
                        <h2 class="main-title">Select a <span>Module</span></h2>
                    </div>
                    <!-- Section Title End -->

                    <!-- Courses Search Start -->
                    <!-- <div class="courses-search">
                        <form action="#">
                            <input type="text" placeholder="Search your course">
                            <button><i class="flaticon-magnifying-glass"></i></button>
                        </form>
                    </div>-->
                    <!-- Courses Search End -->

                </div>
                <!-- All Courses Top End -->

                <!-- All Courses Tabs Menu Start -->
                <!-- <div class="courses-tabs-menu courses-active">
                    <div class="swiper-container">
                        <ul class="swiper-wrapper nav">
                            <li class="swiper-slide"><button class="active" data-bs-toggle="tab" data-bs-target="#tabs1">All</button></li>
                            <li class="swiper-slide"><button data-bs-toggle="tab" data-bs-target="#tabs2">CLMIS</button></li>
                            <li class="swiper-slide"><button data-bs-toggle="tab" data-bs-target="#tabs3">VLMIS</button></li>
                            <li class="swiper-slide"><button data-bs-toggle="tab" data-bs-target="#tabs4">IDSMIS</button></li> 
                        </ul>
                    </div>
 
                    <div class="swiper-button-next"><i class="icofont-rounded-right"></i></div>
                    <div class="swiper-button-prev"><i class="icofont-rounded-left"></i></div>
                </div> -->
                <!-- All Courses Tabs Menu End -->

                <!-- All Courses tab content Start -->
                <div class="tab-content courses-tab-content ">
                    <div class="tab-pane fade show active" id="tabs1">

                        <!-- All Courses Wrapper Start -->
                        <div class="courses-wrapper">
                            <div class="row">
                                <div class="col-lg-4 col-md-6">
                                    <!-- Single Courses Start -->
                                    <div class="single-courses">
                                        <div class="courses-images">
                                            <a href="<?php echo base_url();?>learning/clmis"><img src="assets/images/courses/clmis.jpg" style="height:140px" alt="Courses"></a>
                                        </div>
                                        <div class="courses-content">
                                            <div class="courses-author">
                                                <div class="author">
                                                    <div class="author-thumb">
                                                        <a href="#"><img src="assets/images/author/author-01.jpg" alt="Author"></a>
                                                    </div>
                                                    <div class="author-name">
                                                        <a class="name" href="<?php echo base_url();?>learning/clmis">CLMIS</a>
                                                    </div>
                                                </div>
                                                <div class="tag">
                                                    <a href="<?php echo base_url();?>Learning/clmis">Info</a>
                                                </div>
                                            </div>

                                            <h4 class="title"><a href="learning/clmis">Contraceptive Logistic Management Information System</a></h4>
                                            <!--<div class="courses-meta">
                                                <span> <i class="icofont-clock-time"></i> 08 hr 15 mins</span>
                                                <span> <i class="icofont-read-book"></i> 29 Lectures </span>
                                            </div>-->
                                           <div class="courses-price-review">
                                                <div class="courses-price">
                                                    <span class="sale-parice"><i class="fa fa-language"></i> English</span>
                                                    <!--<span class="old-parice">$440.00</span>-->
                                                </div>
                                                <div class="courses-review">
                                                    <span class="rating-count">Self-Paced</span>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Single Courses End -->
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <!-- Single Courses Start -->
                                    <div class="single-courses">
                                        <div class="courses-images">
                                            <a href="<?php echo base_url();?>learning/vlmis"><img src="assets/images/courses/vaccine_img.jpg" style="height:140px" alt="Courses"></a>
                                        </div>
                                        <div class="courses-content">
                                            <div class="courses-author">
                                                <div class="author">
                                                    <div class="author-thumb">
                                                        <a href="#"><img src="assets/images/author/author-02.jpg" alt="Author"></a>
                                                    </div>
                                                    <div class="author-name">
                                                        <a class="name" href="<?php echo base_url();?>learning/vlmis">VLMIS</a>
                                                    </div>
                                                </div>
                                                <div class="tag">
                                                    <a href="<?php echo base_url();?>Learning/vlmis">Info</a>
                                                </div>
                                            </div>

                                            <h4 class="title"><a href="learning/vlmis">Vaccine Logistics Management Information System
											
											</a></h4>
                                            

                                           <div class="courses-price-review">
                                                <div class="courses-price">
                                                    <span class="sale-parice"><i class="fa fa-language"></i> English</span>
                                                    <!--<span class="old-parice">$440.00</span>-->
                                                </div>
                                                <div class="courses-review">
                                                    <span class="rating-count">Self-Paced</span>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Single Courses End -->
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <div class="single-courses">
                                        <div class="courses-images">
                                            <a href="<?php echo base_url();?>learning/idmis"><img src="assets/images/courses/idmis.jpg" style="height:140px" alt="Courses"></a>
                                        </div>
                                        <div class="courses-content">
                                            <div class="courses-author">
                                                <div class="author">
                                                    <div class="author-thumb">
                                                        <a href="#"><img src="assets/images/author/author-03.jpg" alt="Author"></a>
                                                    </div>
                                                    <div class="author-name">
                                                        <a class="name" href="<?php echo base_url();?>learning/idmis">IDMIS</a>
                                                    </div>
                                                </div>
                                                <div class="tag">
                                                    <a href="<?php echo base_url();?>learning/idmis">Info</a>
                                                </div>
                                            </div>

                                            <h4 class="title"><a href="learning/idmis">Infectious Diseases Management Information System</a></h4>
                                           

                                           <div class="courses-price-review">
                                                <div class="courses-price">
                                                    <span class="sale-parice"><i class="fa fa-language"></i> English</span>
                                                    <!--<span class="old-parice">$440.00</span>-->
                                                </div>
                                                <div class="courses-review">
                                                    <span class="rating-count">Self-Paced</span>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
								
								
								
								
								
								
								<div class="col-lg-4 col-md-6">
                                    <div class="single-courses">
                                        <div class="courses-images">
                                            <a href="<?php echo base_url();?>learning/ecr"><img src="assets/images/courses/ecr.png" style="height:140px" alt="Courses"></a>
                                        </div>
                                        <div class="courses-content">
                                            <div class="courses-author">
                                                <div class="author">
                                                    <div class="author-thumb">
                                                        <a href="#"><img src="assets/images/courses/ecr_logo.png" alt="Author"></a>
                                                    </div>
                                                    <div class="author-name">
                                                        <a class="name" href="<?php echo base_url();?>learning/ecr">ECR</a>
                                                    </div>
                                                </div>
                                                <div class="tag">
                                                    <a href="<?php echo base_url();?>learning/ecr">Details</a>
                                                </div>
                                            </div>

                                            <h4 class="title"><a href="learning/ecr">Electronic Client Record</a></h4>
                                           

                                           <div class="courses-price-review">
                                                <div class="courses-price">
                                                    <span class="sale-parice"><i class="fa fa-language"></i> English</span>
                                                    <!--<span class="old-parice">$440.00</span>-->
                                                </div>
                                                <div class="courses-review">
                                                    <span class="rating-count">Self-Paced</span>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
								
								<div class="col-lg-4 col-md-6">
                                    <div class="single-courses">
                                        <div class="courses-images">
                                            <a href="<?php echo base_url();?>learning/covid_mis"><img src="assets/images/courses/covid.jpg" style="height:140px" alt="Courses"></a>
                                        </div>
                                        <div class="courses-content">
                                            <div class="courses-author">
                                                <div class="author">
                                                    <div class="author-thumb">
                                                        <a href="#"><img src="assets/images/author/author-03.jpg" alt="Author"></a>
                                                    </div>
                                                    <div class="author-name">
                                                        <a class="name" href="<?php echo base_url();?>learning/covid_mis">Covid MIS</a>
                                                    </div>
                                                </div>
                                                <div class="tag">
                                                    <a href="<?php echo base_url();?>learning/covid_mis">Info</a>
                                                </div>
                                            </div>

                                            <h4 class="title"><a href="learning/covid_mis">Covid-19 Management Information System</a></h4>
                                           

                                           <div class="courses-price-review">
                                                <div class="courses-price">
                                                    <span class="sale-parice"><i class="fa fa-language"></i> English</span>
                                                    <!--<span class="old-parice">$440.00</span>-->
                                                </div>
                                                <div class="courses-review">
                                                    <span class="rating-count">Self-Paced</span>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><div class="col-lg-4 col-md-6">
                                    <div class="single-courses">
                                        <div class="courses-images">
                                            <a href="<?php echo base_url();?>learning/bsl_two"><img src="assets/images/courses/bsl2.jpg" style="height:140px" alt="Courses"></a>
                                        </div>
                                        <div class="courses-content">
                                            <div class="courses-author">
                                                <div class="author">
                                                    <div class="author-thumb">
                                                        <a href="#"><img src="assets/images/courses/bsl2_icon.png" alt="Author"></a>
                                                    </div>
                                                    <div class="author-name">
                                                        <a class="name" href="<?php echo base_url();?>learning/bsl_two">BSL2</a>
                                                    </div>
                                                </div>
                                                <div class="tag">
                                                    <a href="<?php echo base_url();?>learning/bsl_two">Info</a>
                                                </div>
                                            </div>

                                            <h4 class="title"><a href="learning/bsl_two">BSL 2 Labs</a></h4>
                                           

                                           <div class="courses-price-review">
                                                <div class="courses-price">
                                                    <span class="sale-parice"><i class="fa fa-language"></i> English</span>
                                                    <!--<span class="old-parice">$440.00</span>-->
                                                </div>
                                                <div class="courses-review">
                                                    <span class="rating-count">Self-Paced</span>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
								
								
								
                            </div>
                        </div>
                        <!-- All Courses Wrapper End -->

                    </div>
                    
                    
                    
                </div>
                <!-- All Courses tab content End -->

                <!-- All Courses BUtton Start -->
<!--                <div class="courses-btn text-center">
                    <a href="courses.html" class="btn btn-secondary btn-hover-primary">Other Course</a>
                </div>-->
                <!-- All Courses BUtton End -->

            </div>
        </div>
        <!-- All Courses End -->

        <!-- Call to Action Start -->
        <div class="section section-padding-02">
            <div class="container">

                <!-- Call to Action Wrapper Start -->
                <div class="call-to-action-wrapper">

                    <img class="cat-shape-01 animation-round" src="assets/images/shape/shape-12.png" alt="Shape">
                    <img class="cat-shape-02" src="assets/images/shape/shape-13.svg" alt="Shape">
                    <img class="cat-shape-03 animation-round" src="assets/images/shape/shape-12.png" alt="Shape">

                    <div class="row align-items-center">
                        <div class="col-md-6">

                            <!-- Section Title Start -->
                            <div class="section-title shape-02">
                                <h5 class="sub-title">Learn more</h5>
                                <h2 class="main-title">Join a course and become an <span>Expert.</span></h2>
                            </div>
                            <!-- Section Title End -->

                        </div>
                        <div class="col-md-6">
                            <div class="call-to-action-btn">
                                <a class="btn btn-primary btn-hover-dark" href="#start">Start Learning</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Call to Action Wrapper End -->

            </div>
        </div>
        <!-- Call to Action End -->

        <!-- How It Work End -->
        <div class="section section-padding mt-n1">
            <div class="container">

                <!-- Section Title Start -->
                <div class="section-title shape-03 text-center">
                    <h5 class="sub-title">Over 300+ supporting documents,tutorials and references</h5>
                    <h2 class="main-title">How It <span> Works?</span></h2>
                </div>
                <!-- Section Title End -->

                <!-- How it Work Wrapper Start -->
                <div class="how-it-work-wrapper">

                    <!-- Single Work Start -->
                    <div class="single-work">
                        <img class="shape-1" src="assets/images/shape/shape-15.png" alt="Shape">

                        <div class="work-icon">
                            <i class="flaticon-transparency"></i>
                        </div>
                        <div class="work-content">
                            <h3 class="title">Find Your Course</h3>
                            <!-- <p>It has survived not only centurie also leap into electronic.</p> -->
                        </div>
                    </div>
                    <!-- Single Work End -->

                    <!-- Single Work Start -->
                    <div class="work-arrow">
                        <img class="arrow" src="assets/images/shape/shape-17.png" alt="Shape">
                    </div>
                    <!-- Single Work End -->

                    <!-- Single Work Start -->
                    <div class="single-work">
                        <img class="shape-2" src="assets/images/shape/shape-15.png" alt="Shape">

                        <div class="work-icon">
                            <i class="flaticon-forms"></i>
                        </div>
                        <div class="work-content">
                            <h3 class="title">Start Learning</h3>
                        </div>
                    </div>
                    <!-- Single Work End -->

                    <!-- Single Work Start -->
                    <div class="work-arrow">
                        <img class="arrow" src="assets/images/shape/shape-17.png" alt="Shape">
                    </div>
                    <!-- Single Work End -->

                    <!-- Single Work Start -->
                    <div class="single-work">
                        <img class="shape-3" src="assets/images/shape/shape-16.png" alt="Shape">

                        <div class="work-icon">
                            <i class="flaticon-badge"></i>
                        </div>
                        <div class="work-content">
                            <h3 class="title">Master Your Field</h3>
                        </div>
                    </div>
                    <!-- Single Work End -->

                </div>

            </div>
        </div>
        <!-- How It Work End -->

        <!-- Download App Start -->
        <div class="section section-padding download-section">

            <div class="app-shape-1"></div>
            <div class="app-shape-2"></div>
            <div class="app-shape-3"></div>
            <div class="app-shape-4"></div>

            <div class="container">

                <!-- Download App Wrapper Start -->
                <div class="download-app-wrapper mt-n6">

                    <!-- Section Title Start -->
                    <div class="section-title section-title-white">
                        <h5 class="sub-title">Ready to start trial?</h5>
                        <h2 class="main-title">Open our training servers & start practicing different modules.</h2>
                    </div>
                    <!-- Section Title End -->

                    <img class="shape-1 animation-right" src="assets/images/shape/shape-14.png" alt="Shape">

                    <!-- Download App Button End -->
                    <div class="download-app-btn">
                        <ul class="app-btn">
                            <li><a href="http://beta.lmis.gov.pk/clmisapp" style="width:100px !important;">cLMIS</a></li>
                            <li><a href="http://beta.lmis.gov.pk" style="width:100px !important;">vLMIS</a></li>
                            <li><a href="http://beta.lmis.gov.pk/idsmis" style="width:100px !important;">IDMIS</a></li>
                        </ul>
                    </div>
                    <!-- Download App Button End -->

                </div>
                <!-- Download App Wrapper End -->

            </div>
        </div>
        <!-- Download App End -->


   <script>
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth',
//            speed: 2000
        });
    });
});
            </script>