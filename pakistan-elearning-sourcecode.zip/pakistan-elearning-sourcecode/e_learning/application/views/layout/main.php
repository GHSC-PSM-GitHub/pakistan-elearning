<?php include 'header.php'; ?>
<?php echo $main_content; ?>
<?php
include 'footer.php';
?>

<?php
if ($this->router->fetch_class() == "admin") {
    
    // include "stock_receive_js.php";
    //  include "stock_issue_js.php";
}
?>