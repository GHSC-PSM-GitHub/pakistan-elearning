<!-- Footer Start  -->
        <div class="section footer-section">

            <!-- Footer Widget Section Start -->
            <div class="footer-widget-section">

                <img class="shape-1 animation-down" src="<?php echo base_url(); ?>assets/images/shape/shape-21.png" alt="Shape">

                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 order-md-1 order-lg-1">

                            <!-- Footer Widget Start -->
                            <div class="footer-widget">
                                <div class="widget-logo">
                                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo"></a>
                                </div>

                                <div class="widget-address">
                                    <h4 class="footer-widget-title">USAID </h4>
                                    <p>GHSC-PSM - Chemonics Inc</p>
                                </div>

                                <ul class="widget-info">
                                    <li>
                                        <p> <i class="flaticon-email"></i> <a href="mailto:support@lmis.gov.pk">support@lmis.gov.pk</a> </p>
                                    </li> 
                                </ul>

                                <ul class="widget-social">
                                <li><a href="https://www.linkedin.com/company/usaid-global-health-supply-chain-program-procurement-and-supply-management/"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="https://www.lmis.gov.pk"><i class="fa fa-globe"></i></a></li> 
                                </ul>
                            </div>
                            <!-- Footer Widget End -->

                        </div>
                        <div class="col-lg-3 order-md-3 order-lg-2">

                            <!-- Footer Widget Link Start -->
                            <div class="footer-widget-link">

                                <!-- Footer Widget Start -->
                                
                                <!-- Footer Widget End -->

                                <!-- Footer Widget Start -->
                                <div class="footer-widget">
                                    <h4 class="footer-widget-title">Quick Links</h4>

                                    <ul class="widget-link">
                                        <li><a href="https://lmis.gov.pk/background.php">Background</a></li>
                                        <li><a href="https://v.lmis.gov.pk/docs/pakistan-supplychain-sops">Publications</a></li>
                                        <li><a href="https://lmis.gov.pk/lmis_videos.php">All Videos</a></li>
                                        <li><a href="https://lmis.gov.pk/bot/index.php">Chat Bot</a></li>
                                        <li><a href="https://api.whatsapp.com/send/?phone=923008361081&text=Hi+lmis&type=phone_number&app_absent=0">Whatsapp Chat</a></li>
                                        <li><a href="https://lmis.gov.pk/awstats.php">System Stats</a></li>
                                    </ul>

                                </div>
                                <!-- Footer Widget End -->

                            </div>
                            <!-- Footer Widget Link End -->

                        </div>
                        <div class="col-md-2 order-md-2 order-lg-3">
							<img width="100px" style="padding-top:200px;" src="<?php echo base_url(); ?>assets/images/fed.png">
                        </div>
                        <div class="col-md-2 order-md-2 order-lg-3">
							<img width="200px" style="padding-top:200px;" src="<?php echo base_url(); ?>assets/images/chemonics.png">
                        </div>
                        <div class="col-md-2 order-md-2 order-lg-3">
							<img width="200px" style="padding-top:250px;" src="<?php echo base_url(); ?>assets/images/psm.png">
                        </div>
                    </div>
                </div>

                <img class="shape-2 animation-left" src="<?php echo base_url(); ?>assets/images/shape/shape-22.png" alt="Shape">

            </div>
            <!-- Footer Widget Section End -->

            <!-- Footer Copyright Start -->
            <div class="footer-copyright">
                <div class="container">

                    <!-- Footer Copyright Start -->
                    <div class="copyright-wrapper">
                        <div class="copyright-link">
                            <!-- <a href="#">Terms of Service</a>-->
                        </div>
                        <div class="copyright-text">
                            <p>&copy; 2023 <span> e-Learning </span> Powered by USAID GHSC-PSM<a href="#">( Chemonics Inc )</a></p>
                        </div>
                    </div>
                    <!-- Footer Copyright End -->

                </div>
            </div>
            <!-- Footer Copyright End -->

        </div>
        <!-- Footer End -->

        <!--Back To Start-->
        <a href="#" class="back-to-top">
            <i class="icofont-simple-up"></i>
        </a>
        <!--Back To End-->

    </div>






    <!-- JS
    ============================================ -->

    <!-- Modernizer & jQuery JS -->
    <script src="<?php echo base_url(); ?>assets/js/vendor/modernizr-3.11.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery-3.5.1.min.js"></script>

    <!-- Bootstrap JS -->
    <!-- <script src="assets/js/plugins/popper.min.js"></script>
    <script src="assets/js/plugins/bootstrap.min.js"></script> -->

    <!-- Plugins JS -->
    <!-- <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/plugins/video-playlist.js"></script>
    <script src="assets/js/plugins/jquery.nice-select.min.js"></script>
    <script src="assets/js/plugins/ajax-contact.js"></script> -->

    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->
    <script src="<?php echo base_url(); ?>assets/js/plugins.min.js"></script>


    <!-- Main JS -->
    <script src="<?php echo base_url(); ?>assets/js/main.js"></script>

</body>

</html>