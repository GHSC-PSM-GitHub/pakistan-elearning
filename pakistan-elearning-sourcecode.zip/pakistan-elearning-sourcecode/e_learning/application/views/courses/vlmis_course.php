<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page Navigation</title>
    <style>
        /* Your CSS styles */
        /* Example styles for buttons and content */
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        .content {
            margin-bottom: 20px;
            padding: 20px;
            border: 1px solid #ccc;
        }
        .navigation {
            text-align: center;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 0 10px;
            background-color: #333;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>

    <div class="container">

        <!-- Content Sections -->
        <div class="content">
            <h2 text-align="center">Introduction to the vLMIS Course</h2>
            <p>
                This is a course designed for you to fully understand the basics of how to to use vLMIS System, Here we have added a couple of videos and manuals for you to get a brief idea about what this system is all about and how to you can manage to use this system. we have added a small questionaire in the end of this course where you would be prompted automatically by successfully completing the course.
                <br><br>
                The quiz in the end of this course will be having some question from the slides and the videos in this course where you would be required to submit correct answers for each question for successful completion of the course.
                <br><br>
                By successful completion of the course you would be awarded with a certificate indicating that you are fully trained to be working on the the vaccine logistics management information system. 
            </p>
        </div>
        <div class="content">
            <div class="tab-content">
                <div class="tab-pane show active" id="">
                    <div class="tab-description">
                        <div class="description-wrapper">
                            <h3 class="tab-title">Introduction:</h3>
                            <p>
                                The Vaccine Logistics Management Information System (vLMIS) is an extension of the Logistics Management Information System (LMIS) and is designed to replace the current paper based logistics information system that is being used for managing the vaccine distribution and logistics. It introduces systematic vaccine product management and create sustainable dependencies among different vaccine procurement procedures and geographical level operations.
                                <br><br>
                                The Vaccine Logistics Management Information System (vLMIS) is designed to monitor and manage the distribution of vaccines nationwide. The system efficiently tracks the movement of vaccines from central storage facility to the health facility level. The system also provides real-time information on the availability of vaccines at each stage of supply chain that contributes in making informed decisions in terms of distribution and delivery.
                                <br><br>
                                It is easy to use and contextualized to fit local stakeholder’s structure and the devolution of health and population programs to provincial governments. The system brings in district and EPI-level reporting by aggregating facility-level data through paper-based reports. With a unified system for reporting and requisitioning, the vLMIS system is able to integrate information from all levels and sectors.
                            </p></div>

                    </div>

                </div>
            </div>
        </div>
        
         <div class="content">
        <div class="single-courses" style="background:#E7F8EE;border: 2px solid #309255;">
            <div class="courses-images">
                <iframe width="100%" height="200" src="https://www.youtube.com/embed/xQFsV9P7Hos" allowfullscreen="">
                </iframe>
            </div>
            <p id="textdesign" class="text-center">vLMIS - Consumption Reporting</p>
            </div>
        </div>
        <div class="content">
            <h2>Page 3</h2>
            <p>This is the content of Page 2. You can replace this with your actual content.</p>
        </div>
                                
        <!-- Navigation Buttons -->
        <div class="navigation">
            <a href="#" class="btn" id="prevBtn">Previous</a>
            <a href="#" class="btn" id="nextBtn">Next</a>
        </div>
    </div>

    <script>
        // JavaScript for navigation
        // Dummy content pages (array of strings)
        const pages = [
            "This is the content of Page 1. You can replace this with your actual content for Page 1.",
            "This is the content of Page 2. You can replace this with your actual content for Page 2.",
            "This is the content of Page 3. You can replace this with your actual content for Page 3.",
            // Add more pages as needed
        ];

        let currentPage = 0; // Index of the current page

        // Function to display content based on the current page index
        function showContent() {
            document.querySelectorAll('.content').forEach((element, index) => {
                if (index === currentPage) {
                    element.style.display = 'block';
                } else {
                    element.style.display = 'none';
                }
            });
        }

        // Initial display of content
        showContent();

        // Event listener for the next button
        document.getElementById('nextBtn').addEventListener('click', function(event) {
            event.preventDefault();
            currentPage = (currentPage + 1) % pages.length;
            showContent();
        });

        // Event listener for the previous button
        document.getElementById('prevBtn').addEventListener('click', function(event) {
            event.preventDefault();
            currentPage = (currentPage - 1 + pages.length) % pages.length;
            showContent();
        });
    </script>

</body>
</html>
